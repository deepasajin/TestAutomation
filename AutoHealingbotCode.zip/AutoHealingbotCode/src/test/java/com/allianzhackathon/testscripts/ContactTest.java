package com.allianzhackathon.testscripts;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.allianzhackathon.automationcore.Base;
import com.allianzhackathon.listeners.TestListener;
import com.allianzhackathon.pages.ContactPage;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.sql.SQLException;

public class ContactTest extends Base {
     ContactPage contact;
    ThreadLocal<ExtentTest> extentTest = TestListener.getTestInstance();

    @Test(priority  = 1,enabled = true , description = "Verification of contact form using healing bot")
    public void verifyContactForm() throws SQLException, FileNotFoundException {
        extentTest.get().assignCategory("Sanity");
        contact=new ContactPage(driver);
        contact.enterName("Adam");
        extentTest.get().log(Status.PASS, "Name entered successfully");
        contact.enterEmailId("adam@outlook.com");
        extentTest.get().log(Status.PASS, "Email id entered successfully");
        contact.enterSubject("GTF Hackathon");
        extentTest.get().log(Status.PASS, "Subject entered successfully");
        contact.enterMessage("Healing bot implemented");
        extentTest.get().log(Status.PASS, "Message entered successfully");
        contact.clickOnSendButton();
        extentTest.get().log(Status.PASS, "Clicked on send Button successfully");
    }






}
