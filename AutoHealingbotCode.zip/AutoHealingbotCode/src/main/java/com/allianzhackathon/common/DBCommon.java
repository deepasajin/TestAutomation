package com.allianzhackathon.common;

import com.allianzhackathon.Utilities.PostgreSQLUtil;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DBCommon extends PostgreSQLUtil {

     /**Method for getting query result**/

    public static List<HashMap<String, String>> getQueryResult(String Queryinput) {
        List<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
        try {
            ResultSet result = connectDatabase(Queryinput);
            ResultSetMetaData metadata = result.getMetaData();
            int columnCount = metadata.getColumnCount();
            String resultStr = "";
            while (result.next()) {
                HashMap<String, String> row = new HashMap<String, String>();
                for (int i = 1; i <= columnCount; ++i) {
                    row.put(metadata.getColumnName(i), result.getString(i));
                }
                list.add(row);
            }
            close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


    /**Method for getting query result with replacer**/

    public static List<HashMap<String, String>> getQueryResultwithReplacer(String Queryinput, String rvalue) {

        Queryinput = Queryinput.replace("replacer", rvalue);

        List<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();

        try {
            ResultSet result = connectDatabase(Queryinput);
            ResultSetMetaData metadata = result.getMetaData();
            int columnCount = metadata.getColumnCount();
            String resultStr = "";
            while (result.next()) {
                HashMap<String, String> row = new HashMap<String, String>();
                for (int i = 1; i <= columnCount; ++i) {
                    row.put(metadata.getColumnName(i), result.getString(i));
                }
                list.add(row);
            }
            close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

}
