package com.allianzhackathon.autohealing;

import com.allianzhackathon.constants.Constants;
import org.apache.commons.lang3.StringUtils;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class AutoHealingBot {

     /***Class path***/
    private final static String SRC_PATH = System.getProperty("user.dir")+Constants.CLASS_FILE;

     /***Method for replacing class file content with new locator**/
    public static List<String> replaceLine(final String pFileName, final String pOldLocator, final String pNewLocator) throws IOException {

        final String lFile = pFileName.replace(".", "\\");
        final String lClassFile = SRC_PATH + "/" + lFile + ".java";
        final FileReader fileReader = new FileReader(new File(lClassFile));
        final BufferedReader buffer = new BufferedReader(fileReader);
        String lContent;
        final List<String> lAlleLines = new ArrayList<String>();

        while ((lContent = buffer.readLine()) != null) {

            lContent = lContent.trim();

            String lValue = StringUtils.substringBetween(lContent, "@FindBy(", ")");

            if (lValue != null) {

                int location = lValue.indexOf('=');

                String ilocatorType = lValue.substring(0,location).trim();

                String ilocatorValue = lValue.substring(location+1,lValue.length()).trim();

                String Ilocator = ilocatorType+"="+ilocatorValue;

                if (Ilocator.equals(pOldLocator)){

                    lContent = lContent.replace(lValue, pNewLocator);
                }
            }
            lAlleLines.add(lContent);
        }

        try {
            FileWriter myWriter = new FileWriter(lClassFile);

            for(String str : lAlleLines){
                myWriter.write(str + System.lineSeparator());
            }
            myWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        buffer.close();

        return lAlleLines;
    }
}
