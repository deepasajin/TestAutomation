package com.allianzhackathon.autohealing;

import com.allianzhackathon.common.DBCommon;
import com.allianzhackathon.constants.Constants;
import com.allianzhackathon.enums.DBQueries;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.epam.healenium.SelfHealingDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

public class AutoHealingBotManager{



public static void AutomaHealing() throws IOException {
    Properties prp = new Properties();
    FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + Constants.CONFIG_FILE);
    prp.load(fis);

    String sgap = prp.getProperty("ScoreGap");

    String aHealing = prp.getProperty("autoHealing");

    int hLimit = Integer.parseInt(prp.getProperty("HLimit"));


    List<HashMap<String,String>> hRData =  DBCommon.getQueryResult(DBQueries.valueOf("Get_healing_reportdata").queryString);

    List<HashMap<String,String>> healingCount =  DBCommon.getQueryResult(DBQueries.valueOf("Get_healingresutl_Count").queryString);

    List<HashMap<String,String>> newDataList =  DBCommon.getQueryResultwithReplacer(DBQueries.valueOf("Get_healingcomponents").queryString,sgap);

    if(hRData.size() !=0 && aHealing.equalsIgnoreCase("true"))  {

        String rData = hRData.get(0).get("reportdata");

        int count = Integer.parseInt(healingCount.get(0).get("healingcount"));

        if (!rData.equals("[]") && (count <= hLimit) && (count != 0)) {

            for (int i = 0; i < newDataList.size(); i++) {

                String filePath = newDataList.get(i).get("class_name");

                /***Previous Locator***/

                String pLocator = newDataList.get(i).get("previous_locator");
                int pEqual = pLocator.indexOf('=');
                String plocatorType = pLocator.substring(0,pEqual).trim();
                String plocatorValue = pLocator.substring(pEqual+1,pLocator.length()).trim();
                String plocator = plocatorType+"="+plocatorValue;


                /***New Locator***/
                String nLocator = newDataList.get(i).get("new_locator");
                int nEqual = nLocator.indexOf('=');
                String nlocatorType = nLocator.substring(0,nEqual).trim();
                String nlocatorValue = nLocator.substring(nEqual+1,nLocator.length()).trim();
                String nlocator = nlocatorType+"="+nlocatorValue;

                if(nlocator.contains("cssSelector"))
                {
                    nlocator =nlocator.replace("cssSelector","css");
                }

                if(plocator.contains("cssSelector"))
                {
                    plocator =plocator.replace("cssSelector","css");
                }

                AutoHealingBot.replaceLine(filePath,plocator,nlocator);

            }
        }
    }
}
}
