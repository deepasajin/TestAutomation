package com.allianzhackathon.constants;

public class Constants {

    /*****constant for configuration property file *******/
    public static final String CONFIG_FILE = "/src/main/resources/config.properties";

    /****Path for java class file***/
    public static final String CLASS_FILE = "\\src\\main\\java";

    /**Wait constants***/
    public static long EXPLICIT_WAIT = 20;


}
