package com.allianzhackathon.enums;

public enum DBQueries {

    Get_healingcomponents("select s.class_name AS class_name, s.method_name AS method_name,\n" +
            "(substring((to_json(CAST(s.locator AS text) :: jsonb)) ->>'type' from 4)) || '= \"' ||  ((to_json(CAST(s.locator AS text) :: jsonb)) ->>'value') || '\"' as  previous_locator,\n" +
            "(substring((to_json(CAST(hr.locator AS text) :: jsonb)) ->>'type' from 4)) || '= \"' ||  ((to_json(CAST(hr.locator AS text) :: jsonb)) ->>'value') || '\"' AS new_locator,\n" +
            "hr.score AS score_gap,\n" +
            "hr.success_healing AS healing_status, hr.create_date AS create_date \n" +
            "FROM healenium.selector As s\n" +
            "INNER JOIN healenium.healing As h\n" +
            "ON s.uid=h.selector_id\n" +
            "INNER JOIN healenium.healing_result AS hr\n" +
            "ON h.uid=hr.healing_id\n" +
            "Where CAST(hr.create_date AS DATE) = current_date\n" +
            "And hr.score > replacer and hr.success_healing is True\n" +
            "ORDER BY hr.create_date DESC LIMIT 3"),

    Get_healing_report_id(" select uid as id from healenium.report ORDER BY create_date DESC LIMIT 1"),

    Get_healing_reportdata("select (to_json(CAST(r.elements AS text) :: jsonb)) ->>'records' as reportdata from healenium.report as r Where CAST(r.create_date AS DATE) = current_date \n" +
            "ORDER BY r.create_date DESC LIMIT 1"),

    Get_healingresutl_Count("select count(*) as healingcount from healenium.healing_result Where CAST(create_date AS DATE) = current_date");


    public String queryString;

    DBQueries(final String queryStr) {
        this.queryString = queryStr;
    }
}
