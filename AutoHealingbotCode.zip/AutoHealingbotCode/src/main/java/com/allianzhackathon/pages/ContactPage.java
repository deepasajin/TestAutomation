package com.allianzhackathon.pages;

import com.epam.healenium.annotation.DisableHealing;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactPage {
    WebDriver driver;

    public ContactPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id="fullname")
    private WebElement nameField;

    @FindBy(name="email")
    private WebElement emailField;

    @FindBy(xpath = "//input[@id='subject_txt']")
    private WebElement subjectField;

    @FindBy(id = "message_txt")
    private WebElement messageField;

    @FindBy(css = "button#sub")
    private WebElement sendButton;

    public void enterName(String name) {
        nameField.sendKeys(name);
    }

    public void enterEmailId(String email) {
        emailField.sendKeys(email);
    }

    public void enterSubject(String subject) {
        subjectField.sendKeys(subject);
    }

    public void enterMessage(String message) {
        messageField.sendKeys(message);
    }

    @DisableHealing
    public void clickOnSendButton() {
        sendButton.click();
    }

}
