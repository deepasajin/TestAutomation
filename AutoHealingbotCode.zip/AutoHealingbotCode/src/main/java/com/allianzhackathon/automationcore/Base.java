package com.allianzhackathon.automationcore;

import com.allianzhackathon.autohealing.AutoHealingBotManager;
import com.allianzhackathon.Utilities.EmailUtility;
import com.allianzhackathon.common.DBCommon;
import com.allianzhackathon.enums.DBQueries;
import com.allianzhackathon.constants.Constants;
import com.allianzhackathon.reports.ExtentReportManager;
import com.allianzhackathon.reports.HealingReport;
import com.epam.healenium.SelfHealingDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.mail.EmailException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class Base {

    public SelfHealingDriver driver;
    public static Properties prop;
    private static String _folderPath;

    /**Constructor**/

    public Base() {
        try {
            prop = new Properties();
            FileInputStream ip = new FileInputStream(System.getProperty("user.dir") + Constants.CONFIG_FILE);
            prop.load(ip);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**Test initialize method**/

    public void testInitialize(String browser, String url) throws MalformedURLException {
        if (browser.equalsIgnoreCase("Chrome")) {
            WebDriverManager.chromedriver().setup();
            WebDriver delegate = new ChromeDriver();
            driver = SelfHealingDriver.create(delegate);
        } else if (browser.equalsIgnoreCase("Firefox")) {
            WebDriverManager.firefoxdriver().setup();
        } else if (browser.equalsIgnoreCase("Edge")) {
            WebDriverManager.edgedriver().setup();
        }
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.get(url);
        driver.manage().timeouts().pageLoadTimeout(Constants.EXPLICIT_WAIT, TimeUnit.SECONDS);
    }
     /**Healing Report forlder path creation**/

    @BeforeSuite
    public void preSuiteConditions(final ITestContext testContext) throws IOException {
        ExtentReportManager.createInstance().createTest(testContext.getName(), "TEST FAILED");
        _folderPath = System.getProperty("user.dir") + "\\HealingReports";
        File f1 = new File(_folderPath);
        if (!new File(_folderPath).exists()) {
            f1.mkdir();
        }
    }
    /**Autohealing anf email report method call**/

    @AfterSuite
    public void getReport() throws EmailException, IOException, InterruptedException {
        AutoHealingBotManager.AutomaHealing();
        getHealingReport();
    }

    /**browser launch**/

    @BeforeMethod
    public void setup() throws MalformedURLException {
        String browser = prop.getProperty("browser");
        String url = prop.getProperty("url");
        testInitialize(browser, url);
    }

    /**browser close**/

    @AfterMethod
    public void tearDown(ITestResult result) throws IOException {
        driver.quit();
    }

    /**Method for downlaoding and sending healing report**/

    public void getHealingReport() throws EmailException {
        String mailid = prop.getProperty("RMailID");
        String dateName = new SimpleDateFormat("yyyyMMdd").format(new Date());
        List<HashMap<String, String>> hReportdata = DBCommon.getQueryResult(DBQueries.valueOf("Get_healing_reportdata").queryString);
        List<HashMap<String, String>> hReportid = DBCommon.getQueryResult(DBQueries.valueOf("Get_healing_report_id").queryString);
        if (hReportdata.size() != 0 && hReportid.size() != 0) {
            String id = hReportid.get(0).get("id");
            String link = "http://localhost:7878/healenium/report/" + id;
            String fileName = "\\healing_report_" + dateName + ".html";
            String destination = _folderPath +fileName;
            File out = new File(destination);
            new Thread(new HealingReport(link, out)).start();
            String rData = hReportdata.get(0).get("reportdata");
            if (!rData.equals("[]")) {
                EmailUtility.sendEmail(_folderPath, fileName, mailid);
            }
        }
    }
}
