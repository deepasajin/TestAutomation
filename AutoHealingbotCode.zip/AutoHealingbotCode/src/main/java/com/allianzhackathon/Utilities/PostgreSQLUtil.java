package com.allianzhackathon.Utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PostgreSQLUtil {

    private static Connection connection;
    static String host;
    static String port ;
    static String username;
    static String password;
    static String DatabaseName="healenium";
    static String URL;

    public static void setEnvironments() {
        host = "localhost";
        port = "5432";
        username= "healenium_user";
        password= "YDk2nmNs4s9aCP6K";
    }

    /****Open the connection****/

    public static ResultSet connectDatabase(String sqlQuery)  {
        try {

            setEnvironments();
            Class.forName("org.postgresql.Driver");
            URL = "jdbc:postgresql://" + host + ":" + port + "/"+ DatabaseName ;
            connection = DriverManager.getConnection(URL,username,password);
            return runQuery(sqlQuery);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /***Query Execution****/

    private static ResultSet runQuery(String query) throws SQLException {
        if (connection == null){
            throw new RuntimeException("No Connection made");
        }
        return connection.prepareStatement(query).executeQuery();
    }


    /**** Closing the connection****/
    public static void close()  {
        try{
            if (connection != null) {
                connection.close();
            }
        }catch(SQLException e) {
            e.printStackTrace();
        }
    }
}
