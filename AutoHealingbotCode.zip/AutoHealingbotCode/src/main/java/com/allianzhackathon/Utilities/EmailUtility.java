package com.allianzhackathon.Utilities;

import org.apache.commons.mail.EmailException;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailUtility {

     /**Method for sending email**/

    public static void sendEmail(String filePath, String fileName,String rMailId) throws EmailException {

        final String username = "GTFTest123@gmail.com";
        final String password = "Test@123";

        Properties props = new Properties();
        props.put("mail.smtp.auth", true);
        props.put("mail.smtp.starttls.enable", true);
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);}
                });
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("GTFTest123@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(rMailId));
            message.setSubject("Healing Report");
            message.setText("Please refer the healing report");
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            Multipart multipart = new MimeMultipart();
            String file = filePath+"//"+fileName;
            DataSource source = new FileDataSource(file);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(fileName);
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart);
            Transport.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
